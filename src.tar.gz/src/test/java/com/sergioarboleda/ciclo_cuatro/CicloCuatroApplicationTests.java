package com.sergioarboleda.ciclo_cuatro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicloCuatroApplicationTests {

	@Test
	void contextLoads() {
	}

}
