package com.sergioarboleda.ciclo_cuatro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CicloCuatroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CicloCuatroApplication.class, args);
	}

}
